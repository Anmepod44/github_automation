from github import Auth
from github import Github
from github import GithubIntegration
import requests
import os
from openai import OpenAI
import json
import boto3
from boto3.dynamodb.conditions import Key
from datetime import datetime


OPENAI_KEY=os.getenv("OPENAI_KEY")
ACCESS_TOKEN =os.getenv("GITHUB_ACCESS_TOKEN")
REPOSITORY_PATH=os.getenv("REPOSITORY_PATH")


client = OpenAI(
    api_key=OPENAI_KEY
)

# Initialize a session using Amazon DynamoDB
dynamodb = boto3.resource('dynamodb')


def add_comment_to_dynamodb(pull_no: str, timestamp: str, comment_id: str, comment: str):
    table = dynamodb.Table('PRFeedback')
    
    # Create the item to be added
    item = {
        'pull_no': pull_no,
        'timestamp': timestamp,
        'comment_id': comment_id,
        'comment': comment
    }
    
    try:
        # Insert the item into the table
        response = table.put_item(Item=item)
        return {
            'statusCode': 200,
            'message': 'Comment added successfully',
            'response': response
        }
    except Exception as e:
        print(f"Error adding comment: {e}")
        return {
            'statusCode': 500,
            'message': 'Error adding comment',
            'error': str(e)
        }
        

def review_code_conflicts(patch,diff):

    context = f"""
        You are assigned as a code reviewer. Your responsibility is to review the provided code and offer recommendations for enhancement. 
        Identify any problematic code snippets, highlight potential issues, and generate the final code enhancements based on your judgement. Note, you must generate code.
        Generate the final code for each conflict and store the result in <code></code> blocks" instead of string. Your output should be the resultant code stored in <code></code> blocks please, 
        anything that doesn't include code should be placed in comments with respect to the programming language used, this includes the file names that come especially after the git ignore file. 
        At the base include a 100 word description of what you merged and why in comments. Please comment out any code that does not align to the desired syntax.\n\n
        f"Here is the diff content explaning the disparity:{diff} \n\n And here is the patch content showing the github suggested fix : {patch}"
    """

    # Make the API request using chat completions
    chat_completion = client.chat.completions.create(
        messages=[
            {
                "role": "user",
                "content": context,
            }
        ],
        model="gpt-4",  # Choose the model suitable for code review, like GPT-4
        max_tokens=500,  # Adjust based on the expected length of the response
        temperature=0.2,  # Lower temperature for more deterministic responses
    )
    
    # Extract and return the response text
    return chat_completion.choices[0].message.content

def download_content(url):
    try:
        # Send a GET request to the provided URL
        response = requests.get(url)
        
        # Raise an exception if the request was unsuccessful
        response.raise_for_status()
        
        # Return the content of the response
        return response.content

    except requests.exceptions.RequestException as e:
        # Print the error if the request fails
        print(f"Error downloading content from {url}: {e}")
        return None



def get_diff_patch(pr):
    #get the patch and diff 
    diff=download_content(pr.diff_url)
    patch=download_content(pr.patch_url)

    return {"patch":patch,"diff":diff}


def lambda_handler(event, context):
    
    if event.get("action") == 'opened':
        # Your code logic here
        auth = Auth.Token(ACCESS_TOKEN)
        g = Github(auth=auth)
        g.get_user().login
        
        # Get a pull request by the number.
        n=event.get("pull_request").get("number")
        repo = g.get_repo(REPOSITORY_PATH)
        pr = repo.get_pull(n)
        
        patches=get_diff_patch(pr)
        
        # Get the diff url
        patch,diff=patches["patch"],patches["diff"]
        
        # Make a call to openai to now get the review.
        review=review_code_conflicts(patch,diff)
        
        #post the review
        post=pr.create_issue_comment(review)
        
        
        #Add the comment to the database.
        comment_id=post.id
        pull_no=n
        timestamp=datetime.now().isoformat() 
        comment=review

    
        add_comment_to_dynamodb(pull_no, timestamp, comment_id, comment)
        
        # Return the body in the response
        return {
            'statusCode': 200,
            'body': f" A call was made for pull request {n} to the lambda function and a review was placed on the pull request. Here is the review \n {review} " 
        }
        
    # Return the body in the response
    return {
        'statusCode': 200,
        'body': "Event Received by the lambda function" 
    }